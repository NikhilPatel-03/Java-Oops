# Practical 2: Inheritance in Java

## Aim
To demonstrate single, multilevel, and hierarchical inheritance in Java.

## Programs
- `SingleInheritance.java` – Vehicle and Car
- `MultilevelInheritance.java` – Person, Employee, and Manager
- `HierarchicalInheritance.java` – Shape, Circle, and Rectangle

## Compile and Run

Run these commands from the project root:

### Single Inheritance
```bash
javac src/SingleInheritance.java
java -cp src SingleInheritance
```

### Multilevel Inheritance
```bash
javac src/MultilevelInheritance.java
java -cp src MultilevelInheritance
```

### Hierarchical Inheritance
```bash
javac src/HierarchicalInheritance.java
java -cp src HierarchicalInheritance
```

## Output

### Single Inheritance
```text
Toyota vehicle is starting.
Brand: Toyota
Speed: 180 km/h
Number of doors: 4
```

### Multilevel Inheritance
```text
Name: Ravi
Age: 35
Employee ID: 501
Salary: 65000.0
Department: IT
```

### Hierarchical Inheritance
```text
This is a shape.
Area of circle: 78.54
This is a shape.
Area of rectangle: 24.00
```

## Result
Single, multilevel, and hierarchical inheritance were demonstrated successfully using Java classes.

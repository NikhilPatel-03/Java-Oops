class Shape {
    void display() {
        System.out.println("This is a shape.");
    }
}

class Circle extends Shape {
    double radius;

    Circle(double radius) {
        this.radius = radius;
    }

    void calculateArea() {
        System.out.printf("Area of circle: %.2f%n", Math.PI * radius * radius);
    }
}

class Rectangle extends Shape {
    double length;
    double breadth;

    Rectangle(double length, double breadth) {
        this.length = length;
        this.breadth = breadth;
    }

    void calculateArea() {
        System.out.printf("Area of rectangle: %.2f%n", length * breadth);
    }
}

public class HierarchicalInheritance {
    public static void main(String[] args) {
        Circle circle = new Circle(5);
        Rectangle rectangle = new Rectangle(4, 6);

        circle.display();
        circle.calculateArea();

        rectangle.display();
        rectangle.calculateArea();
    }
}

class Vehicle {
    String brand;
    int speed;

    Vehicle(String brand, int speed) {
        this.brand = brand;
        this.speed = speed;
    }

    void start() {
        System.out.println(brand + " vehicle is starting.");
    }

    void displayVehicle() {
        System.out.println("Brand: " + brand);
        System.out.println("Speed: " + speed + " km/h");
    }
}

class Car extends Vehicle {
    int numberOfDoors;

    Car(String brand, int speed, int numberOfDoors) {
        super(brand, speed);
        this.numberOfDoors = numberOfDoors;
    }

    void displayCar() {
        displayVehicle();
        System.out.println("Number of doors: " + numberOfDoors);
    }
}

public class SingleInheritance {
    public static void main(String[] args) {
        Car car = new Car("Toyota", 180, 4);
        car.start();
        car.displayCar();
    }
}

/**
 * Demonstrates the Student class by creating three Student objects.
 */
public class Main {
    public static void main(String[] args) {
        // Creating three objects of the Student class
        Student student1 = new Student(101, "Aman", 85, 90, 88);
        Student student2 = new Student(102, "Priya", 92, 87, 95);
        Student student3 = new Student(103, "Rahul", 78, 82, 80);

        // Displaying details of all students
        System.out.println("STUDENT DETAILS");
        student1.displayDetails();
        student2.displayDetails();
        student3.displayDetails();
    }
}

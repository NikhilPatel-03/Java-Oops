/**
 * Represents a student and stores marks in three subjects.
 */
public class Student {
    // Instance variables
    private int rollNumber;
    private String name;
    private double subject1Marks;
    private double subject2Marks;
    private double subject3Marks;

    // Constructor
    public Student(int rollNumber, String name,
                   double subject1Marks, double subject2Marks, double subject3Marks) {
        this.rollNumber = rollNumber;
        this.name = name;
        this.subject1Marks = subject1Marks;
        this.subject2Marks = subject2Marks;
        this.subject3Marks = subject3Marks;
    }

    // Method to calculate total marks (maximum = 300)
    public double calculateTotalMarks() {
        return subject1Marks + subject2Marks + subject3Marks;
    }

    // Method to calculate percentage
    public double calculatePercentage() {
        return (calculateTotalMarks() / 300.0) * 100;
    }

    // Method to display student details
    public void displayDetails() {
        System.out.println("-----------------------------------");
        System.out.println("Roll Number : " + rollNumber);
        System.out.println("Name        : " + name);
        System.out.println("Subject 1   : " + subject1Marks);
        System.out.println("Subject 2   : " + subject2Marks);
        System.out.println("Subject 3   : " + subject3Marks);
        System.out.printf("Total Marks : %.2f / 300%n", calculateTotalMarks());
        System.out.printf("Percentage  : %.2f%%%n", calculatePercentage());
    }
}

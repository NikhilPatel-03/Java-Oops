# Practical 1: Classes and Objects in Java

## Aim
To create a Java `Student` class with a constructor and methods to calculate total marks, percentage, and display student details.

## Requirements
- Store roll number, name, and marks in three subjects.
- Calculate total marks and percentage.
- Create at least three `Student` objects.
- Display each student's details.

## Project Structure

```text
practical-1-classes-and-objects/
├── src/
│   ├── Student.java
│   └── Main.java
├── .gitignore
└── README.md
```

## Source Code
The Java source files are available in the `src` folder:
- `Student.java` defines the `Student` class.
- `Main.java` contains the `main()` method and creates three objects.

## How to Compile and Run

Make sure the Java Development Kit (JDK) is installed.

From the project root, run:

```bash
javac src/Student.java src/Main.java
java -cp src Main
```

## Sample Output

```text
STUDENT DETAILS
-----------------------------------
Roll Number : 101
Name        : Aman
Subject 1   : 85.0
Subject 2   : 90.0
Subject 3   : 88.0
Total Marks : 263.00 / 300
Percentage  : 87.67%
-----------------------------------
Roll Number : 102
Name        : Priya
Subject 1   : 92.0
Subject 2   : 87.0
Subject 3   : 95.0
Total Marks : 274.00 / 300
Percentage  : 91.33%
-----------------------------------
Roll Number : 103
Name        : Rahul
Subject 1   : 78.0
Subject 2   : 82.0
Subject 3   : 80.0
Total Marks : 240.00 / 300
Percentage  : 80.00%
```

## Identification of OOP Concepts

| Concept | Used in this program |
|---|---|
| Class | `Student` |
| Objects | `student1`, `student2`, `student3` |
| Instance variables | `rollNumber`, `name`, `subject1Marks`, `subject2Marks`, `subject3Marks` |
| Constructor | `Student(...)` |
| Methods | `calculateTotalMarks()`, `calculatePercentage()`, `displayDetails()` |

## Formula

- **Total Marks** = Subject 1 + Subject 2 + Subject 3
- **Percentage** = (Total Marks / 300) × 100

Each subject is assumed to be out of 100 marks.

## Result
The program demonstrates classes and objects in Java. It creates three student objects, calculates their total marks and percentages, and displays their details.
